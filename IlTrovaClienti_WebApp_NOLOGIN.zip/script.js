document.getElementById('mostra-altri').addEventListener('click', function() {
  alert('Funzione mostra altri clienti in sviluppo.');
});
